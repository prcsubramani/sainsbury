package uk.co.sainsburys.interview;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uk.co.sainsburys.interview.client.ProductsClient;
import uk.co.sainsburys.interview.client.model.Product;
import uk.co.sainsburys.interview.client.model.ProductPrice;
import uk.co.sainsburys.interview.controller.response.UnifiedProduct;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductsClient productsClient;

    public List<UnifiedProduct> getProducts(final Optional<String> productType) {
        final Set<Product> products;
        final Set<ProductPrice> productsPrices;
        try {
            products = productsClient.getProducts();
            productsPrices = productsClient.getProductsPrices();
            final Map<Integer, ProductPrice> productPricesByUid = productsPrices != null ? productsPrices.stream()
                    .collect(toMap(ProductPrice::productUid, value -> value)) : Map.of();
            if (products != null) {
                return products.stream()
                        .filter(product -> productType.map(inputType -> product.productType().equalsIgnoreCase(inputType)).orElse(true))
                        .filter(product -> productPricesByUid.containsKey(product.productUid()))
                        .map(product -> getUnifiedProduct(product, productPricesByUid.get(product.productUid())))
                        .collect(toList());
            }
            return List.of();
        }catch(Exception exp){
            return List.of();
        }

    }

    private UnifiedProduct getUnifiedProduct(final Product product, final ProductPrice productPrice) {
        return UnifiedProduct.builder()
                .productUid(product.productUid())
                .productType(product.productType())
                .name(product.name())
                .fullUrl(product.fullUrl())
                .unitPrice(productPrice.unitPrice())
                .unitPriceMeasure(productPrice.unitPriceMeasure())
                .unitPriceMeasureAmount(productPrice.unitPriceMeasureAmount())
                .build();
    }
}
