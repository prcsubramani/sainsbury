package uk.co.sainsburys.interview.controller.response;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@Builder
@JsonInclude(NON_NULL)
public record UnifiedProduct(int productUid,
                             String productType,
                             String name,
                             String fullUrl,
                             double unitPrice,
                             String unitPriceMeasure,
                             int unitPriceMeasureAmount) {
}
