package uk.co.sainsburys.interview.client.model;


import lombok.Builder;
import java.util.Objects;


@Builder
public record Product(int productUid,
                      String productType,
                      String name,
                      String fullUrl) {
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final Product product = (Product) o;
        return productUid == product.productUid;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(productUid);
    }
}
