package uk.co.sainsburys.interview.client.model;


import lombok.Builder;

import java.util.Objects;

@Builder
public record ProductPrice(int productUid,
                           double unitPrice,
                           String unitPriceMeasure,
                           int unitPriceMeasureAmount) {

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final ProductPrice that = (ProductPrice) o;
        return productUid == that.productUid;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(productUid);
    }
}