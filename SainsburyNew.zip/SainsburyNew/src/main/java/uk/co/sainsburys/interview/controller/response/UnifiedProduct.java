package uk.co.sainsburys.interview.controller.response;



import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;


@Builder
public record  UnifiedProduct(String productUid,
                              String productType,
                              String name,
                              String fullUrl,
                              double unitPrice,
                              String unitPriceMeasure,
                              int unitPriceMeasureAmount){


}