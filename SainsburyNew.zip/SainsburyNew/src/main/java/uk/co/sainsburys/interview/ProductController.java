package uk.co.sainsburys.interview;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import uk.co.sainsburys.interview.controller.response.UnifiedProduct;

import java.util.List;
import java.util.Optional;

@RestController
@RequiredArgsConstructor
@Slf4j
public class ProductController {

    private final ProductService productService;

    @GetMapping("/products")
    public ResponseEntity<List<UnifiedProduct>> getProducts(HttpServletRequest request, @RequestParam(required = false) String type) {

        return ResponseEntity.ok(productService.getProducts(type));
    }

}
