package uk.co.sainsburys.interview.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;

import java.util.Objects;


@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public record Product(@JsonProperty("product_uid") String productUid,
                      @JsonProperty("product_type") String productType,
                      @JsonProperty("name") String name,@JsonProperty("full_url") String fullUrl) {

    public boolean equals(Object o){
        if(o==null|| getClass() !=o.getClass()){
            return false;
        }
        final Product p = (Product)o;
        return  productUid == p.productUid;
    }

    public int hashCode(){
        return Objects.hashCode(productUid);
    }


}