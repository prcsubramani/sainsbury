package uk.co.sainsburys.interview;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uk.co.sainsburys.interview.client.ProductsClient;
import uk.co.sainsburys.interview.client.model.Product;
import uk.co.sainsburys.interview.client.model.ProductPrice;
import uk.co.sainsburys.interview.controller.response.UnifiedProduct;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductsClient productsClient;

    public List<UnifiedProduct> getProducts(final String type) {
        Set<Product> productDetails = productsClient.getProducts();
        Set<ProductPrice> productPrices = productsClient.getProductsPrices();
        // Create a map of product prices by productUid for efficient lookup
        Map<String, ProductPrice> priceMap = productPrices.stream()
                .collect(toMap(
                        ProductPrice::productUid,
                        price -> price,
                        (existing, replacement) -> existing // Keep first occurrence if duplicates
                ));

        // Merge product details with prices and create unified Product objects
        List<UnifiedProduct> products = productDetails.stream()
                .filter(detail -> priceMap.containsKey(detail.productUid())) // Only include products with prices
                .map(detail -> {
                    ProductPrice price = priceMap.get(detail.productUid());
                    return UnifiedProduct.builder()
                            .productUid(detail.productUid())
                            .productType(detail.productType())
                            .name(detail.name())
                            .fullUrl(detail.fullUrl())
                            .unitPrice(price.unitPrice())
                            .unitPriceMeasure(price.unitPriceMeasure())
                            .unitPriceMeasureAmount(price.unitPriceMeasureAmount()).build();
             }).collect(toList());

        // Apply type filter if provided
        if (type != null && !type.trim().isEmpty()) {
            products = products.stream()
                    .filter(product -> type.equals(product.productType()))
                    .collect(Collectors.toList());
        }
        return products;
    }
}
