package uk.co.sainsburys.interview.client.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;

import java.util.Objects;

@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public record ProductPrice(@JsonProperty("product_uid") String productUid,
                                          @JsonProperty("unit_price")double unitPrice,
                                          @JsonProperty("unit_price_measure") String unitPriceMeasure,
                                          @JsonProperty("unit_price_measure_amount")int unitPriceMeasureAmount)
{

    public boolean equals(Object o){
        if(o==null|| getClass() !=o.getClass()){
            return false;
        }
        final ProductPrice that = (ProductPrice)o;
        return  productUid == that.productUid;
    }

    public int hashCode(){
        return Objects.hashCode(productUid);
    }


}

