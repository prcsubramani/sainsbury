package uk.co.sainsburys.interview;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import uk.co.sainsburys.interview.client.ProductsClient;
import uk.co.sainsburys.interview.client.model.Product;
import uk.co.sainsburys.interview.client.model.ProductPrice;


import java.util.HashSet;
import java.util.Set;

import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.Matchers.*;
import static org.mockito.Mockito.when;


@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = ProductApplication.class, webEnvironment = RANDOM_PORT)
@AutoConfigureMockMvc
public class ProductApplicationIT {

    @Autowired
    private MockMvc mockMvc;


    @Test
    void shouldReturnProductWithPriceInformationForAllProducts() throws Exception {
        mockMvc.perform(get("/products"))
                .andExpectAll(status().isOk(),
                        jsonPath("$.length()").value(3),
                        jsonPath("$.[0].product_uid").value("6447344"),
                        jsonPath("$.[0].product_type").value("BASIC"),
                        jsonPath("$.[0].name").value("Cathedral City Mature Cheddar Cheese 350g"),
                        jsonPath("$.[0].full_url").value("https://www.sainsburys.co.uk/gol-ui/product/cathedral-city-mature-350g"),
                        jsonPath("$.[0].unit_price").value("15.63"),
                        jsonPath("$.[0].unit_price_measure").value("kg"),
                        jsonPath("$.[0].unit_price_measure_amount").value(1),
                        jsonPath("$.[1].product_uid").value("7554911"),
                        jsonPath("$.[1].product_type").value("STANDARD"),
                        jsonPath("$.[1].name").value("Sainsbury's Wafer Thin Air Dried British Ham Slices, Taste the Difference 120g"),
                        jsonPath("$.[1].full_url").value("https://www.sainsburys.co.uk/gol-ui/product/sainsburys-houmous-200g"),
                        jsonPath("$.[1].unit_price").value("0.5"),
                        jsonPath("$.[1].unit_price_measure").value("g"),
                        jsonPath("$.[1].unit_price_measure_amount").value(100),
                        jsonPath("$.[2].product_uid").value("7640075"),
                        jsonPath("$.[2].product_type").value("BASIC"),
                        jsonPath("$.[2].name").value("Sainsbury's Thick Unsmoked Back Bacon Rashers x6 300g"),
                        jsonPath("$.[2].full_url").value("https://www.sainsburys.co.uk/gol-ui/product/sainsburys-thick-unsmoked-bacon-rasher-x6-300g"),
                        jsonPath("$.[2].unit_price").value("5.84"),
                        jsonPath("$.[2].unit_price_measure").value("kg"),
                        jsonPath("$.[2].unit_price_measure_amount").value(10));

    }

    @Test
    void shouldGetProductsFilteredByBasicType() throws Exception {
        mockMvc.perform(get("/products").param("type", "BASIC"))
                .andExpectAll(status().isOk(),
                        jsonPath("$.length()").value(2),
                        jsonPath("$.[0].product_uid").value("6447344"),
                        jsonPath("$.[0].product_type").value("BASIC"),
                        jsonPath("$.[0].name").value("Cathedral City Mature Cheddar Cheese 350g"),
                        jsonPath("$.[0].full_url").value("https://www.sainsburys.co.uk/gol-ui/product/cathedral-city-mature-350g"),
                        jsonPath("$.[0].unit_price").value("15.63"),
                        jsonPath("$.[0].unit_price_measure").value("kg"),
                        jsonPath("$.[0].unit_price_measure_amount").value(1),
                        jsonPath("$.[1].product_uid").value("7640075"),
                        jsonPath("$.[1].product_type").value("BASIC"),
                        jsonPath("$.[1].name").value("Sainsbury's Thick Unsmoked Back Bacon Rashers x6 300g"),
                        jsonPath("$.[1].full_url").value("https://www.sainsburys.co.uk/gol-ui/product/sainsburys-thick-unsmoked-bacon-rasher-x6-300g"),
                        jsonPath("$.[1].unit_price").value("5.84"),
                        jsonPath("$.[1].unit_price_measure").value("kg"),
                        jsonPath("$.[1].unit_price_measure_amount").value(10)
                );
    }

    @Test
    public void shouldReturnEmptyArrayForNonExistentProductType() throws Exception {
        String productType = "NONEXISTENT";
        mockMvc.perform(get("/products").param("type", productType))
                .andExpectAll(status().isOk(),
                        content().contentType(MediaType.APPLICATION_JSON),
                        jsonPath("$", hasSize(0)),
                        jsonPath("$", is(empty())),
                        content().json("[]"));
    }

    @Test
    public void shouldGetProductsWithEmptyProductsResponse() throws Exception {
        mockMvc.perform(get("/products"))
                        .andExpectAll(status().isOk(),
                        content().contentType(MediaType.APPLICATION_JSON),
                        jsonPath("$", hasSize(0)),
                        jsonPath("$", is(empty())));
    }

    @Test
    public void shouldReturnProductsWithNullProductsResponse() throws Exception {
        mockMvc.perform(get("/products"))
                .andExpectAll(status().isOk(),
                        content().contentType(MediaType.APPLICATION_JSON),
                        jsonPath("$", hasSize(0)),
                        jsonPath("$", is(empty())));
    }

    @Test
    public void shouldGetProductsWithMissingPriceData() throws Exception {
        mockMvc.perform(get("/products"))
                .andExpectAll(status().isOk(),
                        content().contentType(MediaType.APPLICATION_JSON),
                        jsonPath("$", hasSize(2)),
                        jsonPath("$[0].product_uid", is(6447344)),
                        jsonPath("$[0].unit_price", is(15.63)),
                        jsonPath("$[1].product_uid", is(7640075)),
                        jsonPath("$[1].unit_price",is(0.0)),
                        jsonPath("$.[1].unit_price_measure").doesNotHaveJsonPath(),
                        jsonPath("$.[1].unit_price_measure_amount",is(0)));

    }

    @Test
    public void shouldReturnEmptyProductsWhenAPIErrorThrown() throws Exception {
        mockMvc.perform(get("/products"))
                .andExpectAll(status().isOk(),
                        content().contentType(MediaType.APPLICATION_JSON),
                        jsonPath("$", hasSize(5)));
    }
    @Test
    public void shouldReturnProductsEndpointResponseAsArray() throws Exception {
        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray());
    }
    @Test
    public void ShouldProductsEndpointReturns200() throws Exception {
        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"));
    }
}
