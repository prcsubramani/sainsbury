package uk.co.sainsburys.interview;

import net.minidev.json.JSONArray;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureWebMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.Matchers.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
class ProductControllerIntegrationTest {
    @Autowired
    private MockMvc mockMvc;

    @Test
    public void endPointShouldReturnsStatusCode200() throws Exception {
        mockMvc.perform(get("/products"))
                .andExpectAll(status().isOk(),
                content().contentType(MediaType.APPLICATION_JSON));
    }

    @Test
    public void shouldReturnProductsEndpointResponseAsArray() throws Exception {
        mockMvc.perform(get("/products"))
                .andExpectAll(status().isOk(),
                 content().contentType(MediaType.APPLICATION_JSON),
                 jsonPath("$").isArray());


    }

    @Test
    public void testCase1_GetAllProducts_ReturnsCorrectStatusAndFormat() throws Exception {

        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$.length()").value(5))
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].product_uid").exists())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].product_type").value("BASIC"))
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].name").value("Sainsbury's Houmous 200g"))
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].full_url").value("https://www.sainsburys.co.uk/gol-ui/product/sainsburys-houmous-200g"))
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price").value(0.5))
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price_measure").value("g"))
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price_measure_amount").value(100))
                .andExpect(jsonPath("$[?(@.product_uid == '6447344')].product_type").value("BASIC"))
                .andExpect(jsonPath("$[?(@.product_uid == '6447344')].name").value("Sainsbury's Skin on ASC Scottish Salmon Fillets x2 240g"))
                .andExpect(jsonPath("$[?(@.product_uid == '6447344')].full_url").value("https://www.sainsburys.co.uk/gol-ui/product/sainsburys-responsibly-sourced-scottish-salmon-fillet-x2-240g"))
                .andExpect(jsonPath("$[?(@.product_uid == '6447344')].unit_price").value(15.63))
                .andExpect(jsonPath("$[?(@.product_uid == '6447344')].unit_price_measure").value("kg"))
                .andExpect(jsonPath("$[?(@.product_uid == '6447344')].unit_price_measure_amount").value(1))
                .andExpect(jsonPath("$[?(@.product_uid == '7511786')].product_type").value("BASIC"))
                .andExpect(jsonPath("$[?(@.product_uid == '7511786')].name").value("Cathedral City Mature Cheddar Cheese 350g"))
                .andExpect(jsonPath("$[?(@.product_uid == '7511786')].full_url").value("https://www.sainsburys.co.uk/gol-ui/product/cathedral-city-mature-350g"))
                .andExpect(jsonPath("$[?(@.product_uid == '7511786')].unit_price").value(8.57))
                .andExpect(jsonPath("$[?(@.product_uid == '7511786')].unit_price_measure").value("kg"))
                .andExpect(jsonPath("$[?(@.product_uid == '7511786')].unit_price_measure_amount").value(1))
                .andExpect(jsonPath("$[?(@.product_uid == '7554911')].product_type").value("BASIC"))
                .andExpect(jsonPath("$[?(@.product_uid == '7554911')].name").value("Sainsbury's Wafer Thin Air Dried British Ham Slices, Taste the Difference 120g"))
                .andExpect(jsonPath("$[?(@.product_uid == '7554911')].full_url").value("https://www.sainsburys.co.uk/gol-ui/product/sainsburys-air-dried-lean-ham-finely-sliced--taste-the-difference-120g"))
                .andExpect(jsonPath("$[?(@.product_uid == '7554911')].unit_price").value(1.88))
                .andExpect(jsonPath("$[?(@.product_uid == '7554911')].unit_price_measure").value("g"))
                .andExpect(jsonPath("$[?(@.product_uid == '7554911')].unit_price_measure_amount").value(100))
                .andExpect(jsonPath("$[?(@.product_uid == '7640075')].product_type").value("BASIC"))
                .andExpect(jsonPath("$[?(@.product_uid == '7640075')].name").value("Sainsbury's Thick Unsmoked Back Bacon Rashers x6 300g"))
                .andExpect(jsonPath("$[?(@.product_uid == '7640075')].full_url").value("https://www.sainsburys.co.uk/gol-ui/product/sainsburys-thick-unsmoked-bacon-rasher-x6-300g"))
                .andExpect(jsonPath("$[?(@.product_uid == '7640075')].unit_price").value(5.84))
                .andExpect(jsonPath("$[?(@.product_uid == '7640075')].unit_price_measure").value("kg"))
                .andExpect(jsonPath("$[?(@.product_uid == '7640075')].unit_price_measure_amount").value(1));

    }

    @Test
    void testCase2_GetProductsWithBasicTypeFilter_ReturnsOnlyBasicProducts() throws Exception {
        mockMvc.perform(get("/products").param("type", "BASIC"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$.length()").value(5))
                .andExpect(jsonPath("$[0].product_type").value("BASIC"))
                .andExpect(jsonPath("$[1].product_type").value("BASIC"));
    }

    @Test
    void testCase3_GetProductsWithPremiumTypeFilter_ReturnsOnlyPremiumProducts() throws Exception {
        // When & Then
        mockMvc.perform(get("/products").param("type", "PREMIUM"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$.length()").value(0));
    }

    // Test Case 4: GET /products?type=NONEXISTENT returns empty array when no matching products found
    @Test
    void testCase4_GetProductsWithNonExistentTypeFilter_ReturnsEmptyArray() throws Exception {
        mockMvc.perform(get("/products").param("type", "NONEXISTENT"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$").isEmpty());
    }



    // Test Case 6: GET /products validates JSON response format with all required fields
    @Test
    void testCase6_GetProducts_ValidatesAllRequiredFieldsInResponse() throws Exception {
        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$.length()").value(5))
                .andExpect(jsonPath("$[0].product_uid").value("7511786"))
                .andExpect(jsonPath("$[1].product_uid").value("7640075"))
                .andExpect(jsonPath("$[2].product_uid").value("6447344"))
                .andExpect(jsonPath("$[3].product_uid").value("7947559"))
                .andExpect(jsonPath("$[4].product_uid").value("7554911"))
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].product_uid").value("7947559"))
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].product_type").exists())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].product_type").isArray())
                .andExpect(jsonPath("$[?(@.product_uid == '0000000')].product_uid").doesNotHaveJsonPath())
                .andExpect(jsonPath("$[?(@.product_uid == '0000000')].product_type").doesNotHaveJsonPath())
                .andExpect(jsonPath("$[?(@.product_uid == '0000000')].name").doesNotHaveJsonPath())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].product_type").exists())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].product_type").isArray())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].product_type").value("BASIC"))
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].name").exists())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].name").isArray())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].name").value("Sainsbury's Houmous 200g"))
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].full_url").exists())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].full_url").isArray())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].full_url").value("https://www.sainsburys.co.uk/gol-ui/product/sainsburys-houmous-200g"))
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price").exists())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price").isArray())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price").value(0.5))
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price_measure").exists())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price_measure").isArray())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price_measure").value("g"))
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price_measure_amount").exists())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price_measure_amount").isArray())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price_measure_amount").value(100));
    }

    @Test
    void testCase6_GetProducts_InValidResponse() throws Exception {
        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$.length()").value(5))
                .andExpect(jsonPath("$[*].product_uid").exists())
                .andExpect(jsonPath("$[*].product_type").value(not(contains("product_type"))))
                .andExpect(jsonPath("$[*].product_type").value(not(hasItems("7947559"))))
                .andExpect(jsonPath("$[?(@.product_uid == '0000000')].product_uid").doesNotHaveJsonPath())
                .andExpect(jsonPath("$[?(@.product_uid == '0000000')].product_type").doesNotHaveJsonPath())
                .andExpect(jsonPath("$[?(@.product_uid == '0000000')].name").doesNotHaveJsonPath())
                .andExpect(jsonPath("$[?(@.product_uid == '0000000')].full_url").doesNotHaveJsonPath())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].product_type").exists())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].product_type").isArray())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].product_type").value("BASIC"))
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].name").exists())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].name").isArray())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].name").value("Sainsbury's Houmous 200g"))
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].full_url").exists())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].full_url").isArray())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].full_url").value("https://www.sainsburys.co.uk/gol-ui/product/sainsburys-houmous-200g"))
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price").exists())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price").isArray())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price").value(0.5))
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price_measure").exists())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price_measure").isArray())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price_measure").value("g"))
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price_measure_amount").exists())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price_measure_amount").isArray())
                .andExpect(jsonPath("$[?(@.product_uid == '7947559')].unit_price_measure_amount").value(100));
    }

    // Test Case 7: GET /products?type= (empty type parameter) returns all products (same as no filter)
    @Test
    void testCase7_GetProductsWithEmptyTypeParameter_ReturnsAllProducts() throws Exception {
          mockMvc.perform(get("/products").param("type", ""))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$.length()").value(5))
                .andExpect(jsonPath("$[0].product_type").value("BASIC"))
                .andExpect(jsonPath("$[1].product_type").value("BASIC"));
    }
}