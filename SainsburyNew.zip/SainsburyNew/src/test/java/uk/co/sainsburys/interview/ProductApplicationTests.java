package uk.co.sainsburys.interview;

import lombok.RequiredArgsConstructor;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = ProductApplication.class, webEnvironment = RANDOM_PORT)
@AutoConfigureMockMvc
class ProductApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void shouldGetProductWithPriceInformationForAllProducts() throws Exception {
        mockMvc.perform(get("/products"))
                .andExpectAll(status().isOk(),
                        jsonPath("$.length()").value(3));
    }

    @Test
    void shouldGetProductWithPriceInformationForASpecificProductType() throws Exception {
        final String productType = "BASIC2";

        mockMvc.perform(get("/products").param("type", productType))
                .andExpectAll(status().isOk(),
                        jsonPath("$.length()").value(3),

                        jsonPath("$.[0].product_uid").value("7511786"),
                        jsonPath("$.[0].product_type").value("BASIC2"),
                        jsonPath("$.[0].name").value("Cathedral City Mature Cheddar Cheese 350g"),
                        jsonPath("$.[0].full_url").value("https://www.sainsburys.co.uk/gol-ui/product/cathedral-city-mature-350g"),
                        jsonPath("$.[0].unit_price").value("8.57"),
                        jsonPath("$.[0].unit_price_measure").value("kg"),
                        jsonPath("$.[0].unit_price_measure_amount").value(1),

                        jsonPath("$.[1].product_uid").value("7554911"),
                        jsonPath("$.[1].product_type").value("BASIC2"),
                        jsonPath("$.[1].name").value("Sainsbury's Wafer Thin Air Dried British Ham Slices, Taste the Difference 120g"),
                        jsonPath("$.[1].full_url").value("https://www.sainsburys.co.uk/gol-ui/product/sainsburys-air-dried-lean-ham-finely-sliced--taste-the-difference-120g"),
                        jsonPath("$.[1].unit_price").value("1.88"),
                        jsonPath("$.[1].unit_price_measure").value("g"),
                        jsonPath("$.[1].unit_price_measure_amount").value(100),

                        jsonPath("$.[2].product_uid").value("7640075"),
                        jsonPath("$.[2].product_type").value("BASIC2"),
                        jsonPath("$.[2].name").value("Sainsbury's Thick Unsmoked Back Bacon Rashers x6 300g"),
                        jsonPath("$.[2].full_url").value("https://www.sainsburys.co.uk/gol-ui/product/sainsburys-thick-unsmoked-bacon-rasher-x6-300g"),
                        jsonPath("$.[2].unit_price").value("5.84"),
                        jsonPath("$.[2].unit_price_measure").value("kg"),
                        jsonPath("$.[2].unit_price_measure_amount").value(1)
                );
    }

    @Test
    void shouldGetProductWithPriceInformationForASpecificProductTypeIgnoringCase() throws Exception {
        final String productType = "bASIC2";

        mockMvc.perform(get("/products").param("type", productType))
                .andExpectAll(status().isOk(),
                        jsonPath("$.length()").value(3));
    }

    @Test
    void shouldReturnStatusOKWithEmptyArrayWhenProductTypeDoesNotMatch() throws Exception {
        final String productTypeNotAMatch = "BASIC100";

        mockMvc.perform(get("/products").param("type", productTypeNotAMatch))
                .andExpectAll(status().isOk(),
                        jsonPath("$.length()").value(0));
    }


}
