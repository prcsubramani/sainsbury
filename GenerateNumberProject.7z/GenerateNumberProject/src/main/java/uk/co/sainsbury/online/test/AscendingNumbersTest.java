package uk.co.sainsbury.online.test;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AscendingNumbersTest {
    @Test
    public void testSingleDigit() {
        String expected = "1,2,3,4,5,6,7,8,9";
        String actual = AscendingNumbers.solve(1);
        assertEquals(expected, actual);
    }

    @Test
    public void testTwoDigits() {
        String expected = "11,12,13,14,15,16,17,18,19,22,23,24,25,26,27,28,29,33,34,35,36,37,38,39,44,45,46,47,48,49,55,56,57,58,59,66,67,68,69,77,78,79,88,89,99";
        String actual = AscendingNumbers.solve(2);
        assertEquals(expected, actual);
    }

    @Test
    public void testThreeDigits() {
        String actual = AscendingNumbers.solve(3);

        String[] numbers = actual.split(",");
        assertTrue(numbers.length > 0, "Should have results");
        assertEquals("111", numbers[0]);
        assertEquals("999", numbers[numbers.length - 1]);
        assertTrue(actual.startsWith("111,112,113"));
        assertTrue(actual.endsWith("999"));

        for (int i = 1; i < numbers.length; i++) {
            assertTrue(Integer.parseInt(numbers[i]) > Integer.parseInt(numbers[i-1]), "Numbers should be in ascending order");
        }

        for (String number : numbers) {
            for (int i = 1; i < number.length(); i++) {
                assertTrue(number.charAt(i) >= number.charAt(i-1), "Digits in " + number + " should be in non-decreasing order");
            }
        }
    }

    @Test
    public void testFourDigits() {
        String actual = AscendingNumbers.solve(4);
        String[] numbers = actual.split(",");

        assertEquals("1111", numbers[0]);

        assertEquals("9999", numbers[numbers.length - 1]);

        assertTrue(actual.contains("1234"));

        // Check that 1243 is NOT included (digits not in order)
        assertFalse(actual.contains("1243"));
    }

    @Test
    public void testEdgeCases() {
        // Test minimum valid input
        assertNotEquals("", AscendingNumbers.solve(1));

        // Test maximum valid input
        assertNotEquals("", AscendingNumbers.solve(9));

        // Test invalid inputs
        assertEquals("", AscendingNumbers.solve(0));
        assertEquals("", AscendingNumbers.solve(10));
        assertEquals("", AscendingNumbers.solve(-1));
    }

    @Test
    void testBoundaryCases() {
        // Test minimum input
        assertEquals("1,2,3,4,5,6,7,8,9", AscendingNumbers.solve(1));

        // Test maximum reasonable input
        String result9 =AscendingNumbers.solve(9);
        assertFalse(result9.isEmpty());
        assertTrue(result9.contains("123456789")); // Only one 9-digit ascending number
    }

    @Test
    public void testSpecificPatterns() {
        // Test 2-digit numbers
        String twoDigits = AscendingNumbers.solve(2);
        // Should contain all same digit pairs
        assertTrue(twoDigits.contains("11"));
        assertTrue(twoDigits.contains("22"));
        assertTrue(twoDigits.contains("33"));
        assertTrue(twoDigits.contains("99"));

        // Should contain ascending pairs
        assertTrue(twoDigits.contains("12"));
        assertTrue(twoDigits.contains("13"));
        assertTrue(twoDigits.contains("89"));

        // Should NOT contain descending pairs
        assertFalse(twoDigits.contains("21"));
        assertFalse(twoDigits.contains("31"));
        assertFalse(twoDigits.contains("98"));
    }

    @Test
    public void testResultCount() {
        // For 1 digit: C(9,1) = 9 numbers
        assertEquals(9, AscendingNumbers.solve(1).split(",").length);

        // For 2 digits: C(9+2-1, 2) = C(10, 2) = 45 numbers
        assertEquals(45, AscendingNumbers.solve(2).split(",").length);

        // For 3 digits: C(9+3-1, 3) = C(11, 3) = 165 numbers
        assertEquals(165, AscendingNumbers.solve(3).split(",").length);
    }

    @Test
    public void testNoLeadingZeros() {
        String result = AscendingNumbers.solve(3);
        String[] numbers = result.split(",");

        // All numbers should start with digit 1-9, not 0
        for (String number : numbers) {
            assertTrue(number.charAt(0) >= '1' && number.charAt(0) <= '9',
                    "Number " + number + " should not have leading zero");
        }
    }

    @Test
    public void testNineDigits() {
        String result = AscendingNumbers.solve(9);
        String[] numbers = result.split(",");
        assertEquals("111111111", numbers[0]);
    }

    @Test
    public void testResultOrdering() {
        String result = AscendingNumbers.solve(3);
        String[] numbers = result.split(",");

        // Convert to integers and verify ordering
        for (int i = 1; i < numbers.length; i++) {
            int prev = Integer.parseInt(numbers[i-1]);
            int curr = Integer.parseInt(numbers[i]);
            assertTrue(curr > prev,
                    "Numbers should be in ascending order: " + prev + " should be < " + curr);
        }
    }
}
