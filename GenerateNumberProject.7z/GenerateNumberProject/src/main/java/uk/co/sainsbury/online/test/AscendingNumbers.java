package uk.co.sainsbury.online.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AscendingNumbers {
    public static String solve(int n) {
        if(n<1 || n>9) {
            return "";
        }
        List<String> results = new ArrayList<>();
        generateAscendingNumbers(n, 1, "", results);
        return String.join(",", results);
    }

    private static void generateAscendingNumbers(int remainingDigits, int startDigit, String current, List<String> results) {
        // Base case: if no more digits needed, add to results
        if (remainingDigits == 0) {
            results.add(current);
            return;
        }

        // Try each digit from startDigit to 9
        for (int digit = startDigit; digit <= 9; digit++) {
            generateAscendingNumbers(remainingDigits - 1, digit, current + digit, results);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        System.out.println(solve(n));
        scanner.close();
    }
}
